** I used PyCharm to run the code and used the terminal for running the application **

1) Keep all the files in the same directory as the application file.

2) Place all the html files in templates directory.

3) Place the css file in static directory.

4) Use export command to let flask know which application file to run
	->export FLASK_APP=app     #In this case app.py is our application file

5) Use export command to let flask run in development mode and turn debugging mode on
	->export FLASK_ENV=development

6) Run the flask application using below command
	->flask run

7) If you want to close the flask application, use Ctrl+C