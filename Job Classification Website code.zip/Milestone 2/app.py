import csv
import pickle
from flask import Flask, render_template, request, redirect
from collections import defaultdict
import random

app = Flask(__name__)


# Load job data from a CSV file
def load_job_data():
    job_data = []
    with open('JobInfo.csv', 'r', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            job_data.append({
                'title': row['Title'],
                'job_id': row['Webindex'],
                'category': row['Category'],
                'company': row['Company'],
                'description': row['Description']
            })
    return job_data


job_data = load_job_data()

with open('vectorizer.pkl', 'rb') as vectorizer_file:
    loaded_vectorizer = pickle.load(vectorizer_file)


# Load the saved model
with open('combined_model.pkl', 'rb') as model_file:
    loaded_model = pickle.load(model_file)


@app.route('/')
def homepage():
    company_job_counts = defaultdict(int)
    jobs_by_company = defaultdict(list)

    for job in job_data:
        if 'company' in job:
            company_name = job['company']
            company_job_counts[company_name] += 1
            jobs_by_company[company_name].append(job)

    return render_template('homepage.html', company_job_counts=company_job_counts, jobs_by_company=jobs_by_company)


@app.route('/jobs/<string:company_name>')
def company_jobs(company_name):
    jobs_for_company = [job for job in job_data if 'company' in job and job['company'] == company_name]
    return render_template('company_jobs.html', company_name=company_name, jobs_for_company=jobs_for_company)


@app.route('/job/<int:job_id>')
def job_details(job_id):
    job = next((job for job in job_data if job['job_id'] == str(job_id)), None)
    if job:
        return render_template('job_details.html', job=job)
    else:
        return "Job not found."


@app.route('/categories')
def categories():
    unique_categories = set(job['category'] for job in job_data if 'category' in job)
    return render_template('categories.html', unique_categories=unique_categories)


@app.route('/category/<string:category_name>')
def category_jobs(category_name):
    jobs_in_category = [job for job in job_data if 'category' in job and job['category'] == category_name]
    return render_template('category_jobs.html', category_name=category_name, jobs_in_category=jobs_in_category)


@app.route('/jobs')
def jobs():
    return render_template('jobs.html', job_data=job_data)


@app.route('/search', methods=['POST'])
def search_jobs():
    query = request.form.get('query')
    results = []

    for job in job_data:
        if 'title' in job and 'category' in job and 'company' in job:
            if (
                query.lower() in job['title'].lower() or
                query.lower() in job['category'].lower() or
                query.lower() in job['company'].lower()
            ):
                results.append(job)

    return render_template('search_results.html', query=query, results=results)


@app.route('/create_job', methods=['GET', 'POST'])
def create_job():
    if request.method == 'POST':
        title = request.form['title']
        company = request.form['company']
        description = request.form['description']

        # Use your model to predict recommended categories based on the description
        recommended_categories = loaded_model.predict(loaded_vectorizer.transform([description]))

        # Set the predicted category
        predicted_category = recommended_categories[0]

        # Check if the user provided an alternative category
        selected_category = request.form.get('selected_category')
        if selected_category:
            category_to_use = selected_category
        else:
            category_to_use = predicted_category

        return render_template('confirm_job.html',
                               title=title,
                               company=company,
                               description=description,
                               predicted_category=predicted_category,
                               selected_category=category_to_use)

    return render_template('create_job.html', predicted_category='', description='')


@app.route('/confirm_job', methods=['POST'])
def confirm_job():
    # Retrieve the selected category from the form in Step 2
    selected_category = request.form['selected_category']

    # Retrieve other job details from the form, e.g., title, description, company
    title = request.form['title']
    company = request.form['company']
    description = request.form['description']

    new_job_id = random.randint(10000000, 99999999)

    # Open the CSV file, write the new job, and close the file
    with open('JobInfo.csv', mode='a', newline='\n', encoding='utf-8') as csvfile:
        fieldnames = ['Title', 'Webindex', 'Category', 'Company', 'Description']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        # Create a new row by writing the new job data
        writer.writerow({
            'Title': title,
            'Webindex': new_job_id,
            'Category': selected_category,
            'Company': company,
            'Description': description
        })

    print("Job created")

    global job_data
    job_data = load_job_data()

    # Redirect to the homepage
    return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)

